#include <iostream>
#include <string>
#include <vector>

#include <signal.h>
#include <cstring>
#include <unistd.h>
#include <poll.h>
#include <errno.h>
#include <limits.h>
#include <sys/signalfd.h>
#include <fcntl.h>

#include <linux/fanotify.h>
#include <sys/fanotify.h>

/* Size of buffer to use when reading fanotify events */
#define FANOTIFY_BUFFER_SIZE 8192

/* Enumerate list of FDs to poll */
enum
{
    FD_POLL_SIGNAL = 0,
    FD_POLL_FANOTIFY,
    FD_POLL_MAX
};

/* Setup fanotify notifications (FAN) mask. All these defined in fanotify.h. */
static uint64_t event_mask =
  (FAN_ACCESS |         /* File accessed */
   FAN_MODIFY |         /* File modified */
   FAN_CLOSE_WRITE |    /* Writtable file closed */
   FAN_CLOSE_NOWRITE |  /* Unwrittable file closed */
   FAN_OPEN |           /* File was opened */
   FAN_ONDIR |          /* We want to be reported of events in the directory */
   FAN_EVENT_ON_CHILD); /* We want to be reported of events in files of the directory */

/* Array of directories being monitored */

std::vector<std::string> monitors;

std::string get_program_name_from_pid(int pid)
{
    int fd;
    ssize_t len;
    char *aux;
    
    char path[PATH_MAX];
    
    std::string program_name = "";
    
    std::string proc_path = std::string("/proc/") + std::to_string(pid) + "/cmdline";

    if ((fd = open (proc_path.c_str(), O_RDONLY)) < 0)
        return program_name;

    /* Read file contents into buffer */
    if ((len = read (fd, path, PATH_MAX - 1)) <= 0)
    {
        close (fd);
        return program_name;
    }
    close (fd);

    path[len] = '\0';
    aux = strstr (path, "^@");
    if (aux)
        *aux = '\0';

    program_name.append(path);
    return program_name;
}

std::string get_file_path_from_fd(int fd)
{
    ssize_t len;
    char path[PATH_MAX];
    
    std::string file_path = "";

    if (fd <= 0)
        return file_path;
    
    std::string fd_path = "/proc/self/fd/";
    fd_path.append(std::to_string(fd));

    if ((len = readlink (fd_path.c_str(), path, PATH_MAX - 1)) < 0)
        return file_path;

    path[len] = '\0';
    file_path.append(path);
    return file_path;
}

static void event_process(struct fanotify_event_metadata *event)
{
    std::string file_path = get_file_path_from_fd (event->fd);
    std::string program_name = get_program_name_from_pid (event->pid);
    
    std::cout << "Received event in path '" << file_path << "' pid=" << event->pid << " (" << program_name << "): " << std::endl;

    if (event->mask & FAN_OPEN)
        printf ("\tFAN_OPEN\n");
    if (event->mask & FAN_ACCESS)
        printf ("\tFAN_ACCESS\n");
    if (event->mask & FAN_MODIFY)
        printf ("\tFAN_MODIFY\n");
    if (event->mask & FAN_CLOSE_WRITE)
        printf ("\tFAN_CLOSE_WRITE\n");
    if (event->mask & FAN_CLOSE_NOWRITE)
        printf ("\tFAN_CLOSE_NOWRITE\n");
    fflush (stdout);

  close (event->fd);
}

static void shutdown_fanotify(int fanotify_fd)
{
    int i;

    for (i = 0; i < monitors.size(); ++i)
    {
        /* Remove the mark, using same event mask as when creating it */
        fanotify_mark (fanotify_fd, FAN_MARK_REMOVE, event_mask, AT_FDCWD, monitors[i].c_str());
        //free (monitors[i].path);
    }

    close (fanotify_fd);
}

static int initialize_fanotify(int argc, const char **argv)
{
    int i;
    int fanotify_fd;

    /* Create new fanotify device */
    if ((fanotify_fd = fanotify_init (FAN_CLOEXEC, O_RDONLY | O_CLOEXEC | O_LARGEFILE)) < 0)
    {
        std::cerr << "Couldn't setup new fanotify device: " << strerror(errno) <<  std::endl;
        return -1;
    }

    /* Allocate array of monitor setups */
    int n_monitors = argc - 1;

    /* Loop all input directories, setting up marks */
    for (i = 0; i < n_monitors; ++i)
    {
        monitors.push_back(std::string(argv[i+1]));
        /* Add new fanotify mark */
        if (fanotify_mark (fanotify_fd, FAN_MARK_ADD, event_mask, AT_FDCWD, monitors[i].c_str()) < 0)
        {
            std::cerr << "Couldn't add monitor in directory '" << monitors[i] << "':'" << strerror(errno) << "'" << std::endl;
            return -1;
        }

        std::cout << "Started monitoring directory '" << monitors[i] << "'" << std::endl;
    }

    return fanotify_fd;
}

static void shutdown_signals(int signal_fd)
{
    close(signal_fd);
}

static int initialize_signals()
{
    int signal_fd;
    sigset_t sigmask;

    /* We want to handle SIGINT and SIGTERM in the signal_fd, so we block them. */
    sigemptyset (&sigmask);
    sigaddset (&sigmask, SIGINT);
    sigaddset (&sigmask, SIGTERM);

    if (sigprocmask (SIG_BLOCK, &sigmask, NULL) < 0)
    {
        std::cerr << "Couldn't block signals: '" << strerror(errno) << "'" << std::endl;
        return -1;
    }

    /* Get new FD to read signals from it */
    if ((signal_fd = signalfd (-1, &sigmask, 0)) < 0)
    {
        std::cerr << "Couldn't setup signal FD: '" << strerror(errno) << "'" << std::endl;
        return -1;
    }

    return signal_fd;
}

int main(int argc, const char **argv)
{
    int signal_fd;
    int fanotify_fd;
    struct pollfd fds[FD_POLL_MAX];

    /* Input arguments... */
    if (argc < 2)
    {
        std::cerr << "Usage: " << argv[0] << "dir1 [dir2 ...]" << std::endl;
        exit (EXIT_FAILURE);
    }

    /* Initialize signals FD */
    if ((signal_fd = initialize_signals ()) < 0)
    {
        std::cerr << "Couldn't initialize signals" << std::endl;
        exit (EXIT_FAILURE);
    }

    /* Initialize fanotify FD and the marks */
    if ((fanotify_fd = initialize_fanotify (argc, argv)) < 0)
    {
        std::cerr << "Couldn't initialize fanotify" << std::endl;
        exit (EXIT_FAILURE);
    }

    /* Setup polling */
    fds[FD_POLL_SIGNAL].fd = signal_fd;
    fds[FD_POLL_SIGNAL].events = POLLIN;
    fds[FD_POLL_FANOTIFY].fd = fanotify_fd;
    fds[FD_POLL_FANOTIFY].events = POLLIN;

    /* Now loop */
    for (;;)
    {
        /* Block until there is something to be read */
        if (poll (fds, FD_POLL_MAX, -1) < 0)
        {
            std::cerr << "Couldn't poll(): '" << strerror(errno) << "'" << std::endl;
            exit (EXIT_FAILURE);
        }

        /* Signal received? */
        if (fds[FD_POLL_SIGNAL].revents & POLLIN)
        {
            struct signalfd_siginfo fdsi;

            if (read (fds[FD_POLL_SIGNAL].fd, &fdsi, sizeof (fdsi)) != sizeof (fdsi))
            {
                std::cerr  << "Couldn't read signal, wrong size read" << std::endl;
                exit (EXIT_FAILURE);
            }

            /* Break loop if we got the expected signal */
            if (fdsi.ssi_signo == SIGINT || fdsi.ssi_signo == SIGTERM)
            {
                break;
            }

            std::cerr << "Received unexpected signal" << std::endl;
        }

        /* fanotify event received? */
        if (fds[FD_POLL_FANOTIFY].revents & POLLIN)
        {
            char buffer[FANOTIFY_BUFFER_SIZE];
            ssize_t length;

            /* Read from the FD. It will read all events available up to
            * the given buffer size. */
            if ((length = read (fds[FD_POLL_FANOTIFY].fd, buffer, FANOTIFY_BUFFER_SIZE)) > 0)
            {
                struct fanotify_event_metadata *metadata;

                metadata = (struct fanotify_event_metadata *)buffer;
                while (FAN_EVENT_OK (metadata, length))
                {
                    event_process (metadata);
                    if (metadata->fd > 0)
                        close (metadata->fd);
                    metadata = FAN_EVENT_NEXT (metadata, length);
                }
            }
        }
    }

    /* Clean exit */
    shutdown_fanotify (fanotify_fd);
    shutdown_signals (signal_fd);

    std::cout << "Exiting fsmonitor..." << std::endl;

    return EXIT_SUCCESS;
}
