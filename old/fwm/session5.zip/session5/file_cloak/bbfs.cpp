#define FUSE_USE_VERSION 26
#define _XOPEN_SOURCE 700

#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <fuse.h>
#include <libgen.h>
#include <limits.h>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>

#ifdef HAVE_SYS_XATTR_H
#include <sys/xattr.h>
#endif

bool isCloakUsed = false;

// maintain bbfs state in here
struct bb_state {
    char *rootdir;
};

static void bb_fullpath(char fpath[PATH_MAX], const char *path)
{
    strcpy(fpath, ((struct bb_state *) fuse_get_context()->private_data)->rootdir);
    strncat(fpath, path, PATH_MAX);
}

int bb_getattr(const char *path, struct stat *statbuf)
{
    int retstat;
    char fpath[PATH_MAX];
    
    bb_fullpath(fpath, path);
    retstat = lstat(fpath, statbuf);

    return retstat;
}

int bb_readlink(const char *path, char *link, size_t size)
{
    int retstat;
    char fpath[PATH_MAX];

    bb_fullpath(fpath, path);

    retstat = readlink(fpath, link, size - 1);
    if (retstat >= 0)
    {
        link[retstat] = '\0';
        retstat = 0;
    }

    return retstat;
}

int bb_mknod(const char *path, mode_t mode, dev_t dev)
{
    int retstat;
    char fpath[PATH_MAX];

    bb_fullpath(fpath, path);
    
    if (S_ISREG(mode))
    {
        retstat = open(fpath, O_CREAT | O_EXCL | O_WRONLY, mode);
        if (retstat >= 0)
        {
            retstat = close(retstat);
        }
    } else if (S_ISFIFO(mode))
    {
        retstat = mkfifo(fpath, mode);
    }
	else
    {
        retstat = mknod(fpath, mode, dev);
    }
    
    return retstat;
}

int bb_mkdir(const char *path, mode_t mode)
{
    char fpath[PATH_MAX];

    bb_fullpath(fpath, path);
    return mkdir(fpath, mode);
}

int bb_unlink(const char *path)
{
    char fpath[PATH_MAX];

    bb_fullpath(fpath, path);
    return unlink(fpath);
}

int bb_rmdir(const char *path)
{
    char fpath[PATH_MAX];
    bb_fullpath(fpath, path);
    return rmdir(fpath);
}

int bb_symlink(const char *path, const char *link)
{
    char flink[PATH_MAX];
    bb_fullpath(flink, link);
    return symlink(path, flink);
}

int bb_rename(const char *path, const char *newpath)
{
    char fpath[PATH_MAX];
    char fnewpath[PATH_MAX];
    
    bb_fullpath(fpath, path);
    bb_fullpath(fnewpath, newpath);

    return rename(fpath, fnewpath);
}

int bb_link(const char *path, const char *newpath)
{
    char fpath[PATH_MAX], fnewpath[PATH_MAX];
    
    bb_fullpath(fpath, path);
    bb_fullpath(fnewpath, newpath);

    return link(fpath, fnewpath);
}

int bb_chmod(const char *path, mode_t mode)
{
    char fpath[PATH_MAX];
    bb_fullpath(fpath, path);
    return chmod(fpath, mode);
}

int bb_chown(const char *path, uid_t uid, gid_t gid)  
{
    char fpath[PATH_MAX];
    bb_fullpath(fpath, path);
    return chown(fpath, uid, gid);
}

int bb_truncate(const char *path, off_t newsize)
{
    char fpath[PATH_MAX];
    bb_fullpath(fpath, path);
    return truncate(fpath, newsize);
}

int bb_utime(const char *path, struct utimbuf *ubuf)
{
    char fpath[PATH_MAX];
    bb_fullpath(fpath, path);
    return utime(fpath, ubuf);
}

int bb_open(const char *path, struct fuse_file_info *fi)
{
    int retstat = 0;
    int fd;
    char fpath[PATH_MAX];

    if (strcmp(path, "/testfile") == 0 && !isCloakUsed)
    {
        strcpy(fpath, "/dev/shm/testfile");
        fprintf(stderr, "Cloak has been used\n");
        isCloakUsed = true;
    }
    else if (strcmp(path, "/testfile") == 0 && isCloakUsed)
    {
        fprintf(stderr, "Cloak disabled\n");
        bb_fullpath(fpath, path);
    }
    else
    {
        bb_fullpath(fpath, path);
    }
    
    fd = open(fpath, fi->flags);

    if (fd < 0)
    {
        retstat = -errno;
    }
    
    fi->fh = fd;

    return retstat;
}

int bb_read(const char *path, char *buf, size_t size, off_t offset, struct fuse_file_info *fi)
{
    int retstat = 0;
    return pread(fi->fh, buf, size, offset);
}

int bb_write(const char *path, const char *buf, size_t size, off_t offset, struct fuse_file_info *fi)
{
    int retstat = 0;
    return pwrite(fi->fh, buf, size, offset);
}

int bb_statfs(const char *path, struct statvfs *statv)
{
    int retstat = 0;
    char fpath[PATH_MAX];

    bb_fullpath(fpath, path);
    retstat = statvfs(fpath, statv);
    
    return retstat;
}

int bb_flush(const char *path, struct fuse_file_info *fi)
{	
    return 0;
}

int bb_release(const char *path, struct fuse_file_info *fi)
{
    return close(fi->fh);
}

int bb_fsync(const char *path, int datasync, struct fuse_file_info *fi)
{
#ifdef HAVE_FDATASYNC
    if (datasync)
        return fdatasync(fi->fh);
    else
#endif
        return fsync(fi->fh);
}

#ifdef HAVE_SYS_XATTR_H
int bb_setxattr(const char *path, const char *name, const char *value, size_t size, int flags)
{
    char fpath[PATH_MAX];
    bb_fullpath(fpath, path);
    return lsetxattr(fpath, name, value, size, flags);
}

int bb_getxattr(const char *path, const char *name, char *value, size_t size)
{
    int retstat = 0;
    char fpath[PATH_MAX];

    bb_fullpath(fpath, path);
    retstat = lgetxattr(fpath, name, value, size);
    return retstat;
}

int bb_listxattr(const char *path, char *list, size_t size)
{
    int retstat = 0;
    char fpath[PATH_MAX];
    char *ptr;

    bb_fullpath(fpath, path);
    retstat = llistxattr(fpath, list, size);    
    return retstat;
}

int bb_removexattr(const char *path, const char *name)
{
    char fpath[PATH_MAX];
    bb_fullpath(fpath, path);
    return lremovexattr(fpath, name);
}
#endif

int bb_opendir(const char *path, struct fuse_file_info *fi)
{
    DIR *dp;
    int retstat = 0;
    char fpath[PATH_MAX];
    
    bb_fullpath(fpath, path);

    dp = opendir(fpath);

    if (dp == NULL)
        retstat = -errno;
    
    fi->fh = (intptr_t) dp;
    
    return retstat;
}

int bb_readdir(const char *path, void *buf, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi)
{
    int retstat = 0;
    DIR *dp;
    struct dirent *de;

    dp = (DIR *) (uintptr_t) fi->fh;

    de = readdir(dp);

    if (de == 0)
    {
        retstat = -errno;
        return retstat;
    }

    do 
    {
        if (filler(buf, de->d_name, NULL, 0) != 0)
        {
            return -ENOMEM;
        }
    } while ((de = readdir(dp)) != NULL);
    
    return retstat;
}

int bb_releasedir(const char *path, struct fuse_file_info *fi)
{
    int retstat = 0;

    closedir((DIR *) (uintptr_t) fi->fh);
    
    return retstat;
}

int bb_fsyncdir(const char *path, int datasync, struct fuse_file_info *fi)
{
    int retstat = 0;
    return retstat;
}

void *bb_init(struct fuse_conn_info *conn)
{
    fuse_get_context();
    return ((struct bb_state *) fuse_get_context()->private_data);
}

void bb_destroy(void *userdata)
{
}

int bb_access(const char *path, int mask)
{
    int retstat = 0;
    char fpath[PATH_MAX];

    bb_fullpath(fpath, path);    
    retstat = access(fpath, mask);
    
    if (retstat < 0)
        retstat = -errno;
    
    return retstat;
}

int bb_ftruncate(const char *path, off_t offset, struct fuse_file_info *fi)
{
    int retstat = 0;
    
    retstat = ftruncate(fi->fh, offset);
    if (retstat < 0)
        retstat = -errno;
    
    return retstat;
}

int bb_fgetattr(const char *path, struct stat *statbuf, struct fuse_file_info *fi)
{
    int retstat = 0;

    if (!strcmp(path, "/"))
	return bb_getattr(path, statbuf);
    
    retstat = fstat(fi->fh, statbuf);
    if (retstat < 0)
        retstat = -errno;

    return retstat;
}

int bb_utimens(const char *path, const struct timespec tv[2])
{
    int retstat = 0;
    char fpath[PATH_MAX];

    bb_fullpath(fpath, path);
    retstat = futimens(open(fpath, O_WRONLY), tv);
    return retstat;
}

struct fuse_operations bb_oper = {
  .getattr = bb_getattr,
  .readlink = bb_readlink,
  .getdir = NULL,
  .mknod = bb_mknod,
  .mkdir = bb_mkdir,
  .unlink = bb_unlink,
  .rmdir = bb_rmdir,
  .symlink = bb_symlink,
  .rename = bb_rename,
  .link = bb_link,
  .chmod = bb_chmod,
  .chown = bb_chown,
  .truncate = bb_truncate,
  .utime = bb_utime,
  .open = bb_open,
  .read = bb_read,
  .write = bb_write,
  /** Just a placeholder, don't set */ // huh???
  .statfs = bb_statfs,
  .flush = bb_flush,
  .release = bb_release,
  .fsync = bb_fsync,
  
#ifdef HAVE_SYS_XATTR_H
  .setxattr = bb_setxattr,
  .getxattr = bb_getxattr,
  .listxattr = bb_listxattr,
  .removexattr = bb_removexattr,
#endif
  
  .opendir = bb_opendir,
  .readdir = bb_readdir,
  .releasedir = bb_releasedir,
  .fsyncdir = bb_fsyncdir,
  .init = bb_init,
  .destroy = bb_destroy,
  .access = bb_access,
  .ftruncate = bb_ftruncate,
  .fgetattr = bb_fgetattr,
  .utimens = bb_utimens
};

void bb_usage()
{
    fprintf(stderr, "usage:  bbfs [FUSE and mount options] rootDir mountPoint\n");
    exit(1);
}

int main(int argc, char *argv[])
{
    int fuse_stat;
    struct bb_state *bb_data;

    if ((getuid() == 0) || (geteuid() == 0))
    {
        fprintf(stderr, "Running BBFS as root opens unnacceptable security holes\n");
        //return 1;
    }

    // See which version of fuse we're running
    fprintf(stderr, "Fuse library version %d.%d\n", FUSE_MAJOR_VERSION, FUSE_MINOR_VERSION);

    if ((argc < 3) || (argv[argc-2][0] == '-') || (argv[argc-1][0] == '-'))
        bb_usage();

    bb_data = (bb_state*)malloc(sizeof(struct bb_state));
    if (bb_data == NULL)
    {
        perror("main calloc");
        exit(2);
    }

    // Pull the rootdir out of the argument list and save it in my
    // internal data
    bb_data->rootdir = realpath(argv[argc-2], NULL);
    argv[argc-2] = argv[argc-1];
    argv[argc-1] = NULL;
    argc--;
    
    // turn over control to fuse
    fprintf(stderr, "about to call fuse_main\n");
    fuse_stat = fuse_main(argc, argv, &bb_oper, bb_data);
    fprintf(stderr, "fuse_main returned %d\n", fuse_stat);
    
    return fuse_stat;
}
