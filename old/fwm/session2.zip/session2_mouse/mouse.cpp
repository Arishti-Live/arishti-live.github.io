#include <X11/Xlib.h>
#include <X11/extensions/XInput.h>
#include <X11/extensions/XInput2.h>
#include <X11/Xutil.h>

#include <iostream>
#include <cstdlib>
//#include <cstring>

static void print_rawevent(Display *display, XGenericEventCookie *cookie)
{
    XIRawEvent *event = (XIRawEvent*)cookie->data;
    
    // check for clicks
    if (cookie->evtype == 15 && event->detail == 1)
        std::cout << "Left Button Press" << std::endl;
    else if (cookie->evtype == 15 && event->detail == 3)
        std::cout << "Right Button Press" << std::endl;
    else if (cookie->evtype == 16 && event->detail == 1)
        std::cout << "Left Button Release" << std::endl;
    else if (cookie->evtype == 16 && event->detail == 3)
        std::cout << "Right Button Release" << std::endl;
    
    // check for movement
    
    static int prevX = -1, prevY = -1;
    
    if (cookie->evtype == 17 && event->detail == 0)
    {
        Window root, child;
        int rootX, rootY, winX, winY;
        unsigned int mask;
        
        XQueryPointer(display,DefaultRootWindow(display),&root,&child,&rootX,&rootY,&winX,&winY,&mask);
        
        if (prevX == -1 || prevY == -1)
        {
            std::cout << "Mouse Pointer Moved to (" << rootX << ", " << rootY << ")" << std::endl;
        }
        else if (rootX != prevX && rootY != prevY)
        {
            std::cout << "Mouse Pointer Moved from (" << prevX << ", " << prevY << ") to (" << rootX << ", " << rootY << ")" << std::endl;
        }
        
        prevX = rootX;
        prevY = rootY;
    }
}

int intercept_mouse(Display *display, int xi_opcode)
{
    XIEventMask mask[2];
    XIEventMask *m;
    Window win;
    int deviceid = -1;
    int use_root = 1;

    setvbuf(stdout, NULL, _IOLBF, 0);
    
    win = DefaultRootWindow(display);

    /* Select for motion events */
    m = &mask[0];
    m->deviceid = XIAllDevices;
    m->mask_len = XIMaskLen(XI_LASTEVENT);
    m->mask = new unsigned char[m->mask_len]();

    m = &mask[1];
    m->deviceid = XIAllMasterDevices;
    m->mask_len = XIMaskLen(XI_LASTEVENT);
    m->mask = new unsigned char[m->mask_len]();
    
    XISetMask(m->mask, XI_RawButtonPress);
    XISetMask(m->mask, XI_RawButtonRelease);
    XISetMask(m->mask, XI_RawMotion);

    XISelectEvents(display, win, &mask[0], 2);
    XSync(display, False);
    
    delete[] (mask[0].mask);
    delete[] (mask[1].mask);

    while(1)
    {
        XEvent ev;
        XGenericEventCookie *cookie = (XGenericEventCookie*)&ev.xcookie;
        XNextEvent(display, (XEvent*)&ev);

        if (XGetEventData(display, cookie) &&
            cookie->type == GenericEvent &&
            cookie->extension == xi_opcode)
        {
            switch (cookie->evtype)
            {
                case XI_RawButtonPress:
                case XI_RawButtonRelease:
                case XI_RawMotion:
                    print_rawevent(display, cookie);
                    break;
            }
        }

        XFreeEventData(display, cookie);
    }

    XDestroyWindow(display, win);

    return 1;
}

int main(int argc, char * argv[])
{
    Display	*display;
    int event, error;
    int xi_opcode;

    display = XOpenDisplay(NULL);

    if (display == NULL)
    {
        std::cerr << "Unable to connect to X server" << std::endl;
        return 1;
    }

    if (!XQueryExtension(display, "XInputExtension", &xi_opcode, &event, &error))
    {
        std::cerr << "X Input extension not available.\n" <<std::endl;
        XCloseDisplay(display);
        return 2;
    }

    int	r = intercept_mouse(display, xi_opcode);
        
    return 0;
}
